
----------Instructions on how to Run the Codes-----------------

   1. R Code:
	- The code has been saved in the folder [weekly_payroll_in_R]
	- Run the code using R-Studio, to generate payslip for 599 workers dynamically.

   2. Python Code:
	- The code has been saved in the folder [Weekly_payroll_in_Python]
	- Run the code using VS code to generate payslips for 599 workers dynamically.


  3. The link to the project oh Githus is:
	
	https://github.com/Chirchirp/Programming_in_R_and_Python	

	Thank you!.