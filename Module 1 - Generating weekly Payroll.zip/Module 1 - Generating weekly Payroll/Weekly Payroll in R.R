# Using a function to generate employee details

generate_employees <- function() {
  employee_id <- sample(1:600, 1)
  employee_name <- paste0("Employee", employee_id)
  weekly_salary <- sample(5000:30000, 1)
  employee_gender <- sample(c("Male", "Female"), 1)
  
  return(c(employee_id, employee_name, weekly_salary, employee_gender))
}

payslip_count <- 0

for (i in 1:600) {
  # Error handling
  worker_details <- try(generate_employees(), silent = TRUE)
  if (inherits(worker_details, "try-error")) {
    cat("Error:", geterrmessage(), "\n")
    next  
  }
  
  employee_id <- worker_details[1]
  employee_name <- worker_details[2]
  weekly_salary <- worker_details[3]
  employee_gender <- worker_details[4]
  
  if (10000 < weekly_salary && weekly_salary < 20000) {
    employee_level <- "A1"
  } else if (7500 < weekly_salary && weekly_salary < 30000 && employee_gender == "Female") {
    employee_level <- "A5-F"
  } else {
    employee_level <- "Unknown level"
  }
  
  cat("Weekly Payroll details\n")
  cat("Employee ID:", employee_id, "\n")
  cat("Name:", employee_name, "\n")
  cat("Gender:", employee_gender, "\n")
  cat("Salary: $", format(weekly_salary, big.mark=","), "\n")
  cat("Worker Level:", employee_level, "\n")
  cat(rep("_", 25), "\n")
  
  payslip_count <- payslip_count + 1

}

cat("Total Payslips Generated:", payslip_count, "\n")
